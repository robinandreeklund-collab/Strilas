%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-06-17T12:46:12+00:00*%
%TF.ProjectId,led-tab,6c65642d-7461-4622-9e6b-696361645f70,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-06-17 12:46:12*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.084000X-1.066000X-0.266000X1.066000X-0.266000X1.066000X0.266000X-1.066000X0.266000X0*%
%ADD11RoundRect,0.174000X-0.976000X-0.551000X0.976000X-0.551000X0.976000X0.551000X-0.976000X0.551000X0*%
%ADD12R,1.700000X1.700000*%
%ADD13O,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,D1*%
X150000000Y-116450000D03*
D11*
X150000000Y-118075000D03*
%TD*%
D12*
%TO.C,J1*%
X148730000Y-123500000D03*
D13*
X151270000Y-123500000D03*
%TD*%
M02*
